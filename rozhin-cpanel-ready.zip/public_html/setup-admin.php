<?php

require_once __DIR__ . '/app/bootstrap.php';

header('Cache-Control: no-store, no-cache, must-revalidate');
header('X-Robots-Tag: noindex, nofollow');

$adminExists = Database::fetch("SELECT id FROM users WHERE role = 'admin' LIMIT 1");
if ($adminExists) {
    http_response_code(403);
    exit('راه‌اندازی مدیر قبلاً انجام شده است. این فایل را از هاست حذف کنید.');
}

$expectedToken = (string) env('SETUP_TOKEN', '');
$message = '';
$success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCsrf($_POST['_csrf'] ?? '')) {
        http_response_code(419);
        exit('درخواست نامعتبر است.');
    }

    $setupToken = trim((string) ($_POST['setup_token'] ?? ''));
    $name = trim((string) ($_POST['name'] ?? ''));
    $family = trim((string) ($_POST['family'] ?? ''));
    $phone = trim((string) ($_POST['phone'] ?? ''));
    $email = trim((string) ($_POST['email'] ?? ''));
    $password = (string) ($_POST['password'] ?? '');

    if ($expectedToken === '' || !hash_equals($expectedToken, $setupToken)) {
        $message = 'کد راه‌اندازی اشتباه است.';
    } elseif ($name === '' || $family === '' || $phone === '') {
        $message = 'نام، نام خانوادگی و تلفن الزامی است.';
    } elseif (mb_strlen($password) < 10) {
        $message = 'رمز عبور باید حداقل ۱۰ کاراکتر باشد.';
    } elseif (Database::fetch("SELECT id FROM users WHERE phone = ?", [$phone])) {
        $message = 'این شماره تلفن قبلاً ثبت شده است.';
    } else {
        Database::insert('users', [
            'name' => $name,
            'family' => $family,
            'phone' => $phone,
            'email' => $email,
            'password' => Auth::hash($password),
            'role' => 'admin',
            'level' => 'gold',
            'is_active' => 1,
        ]);
        $success = true;
        $message = 'مدیر ساخته شد. اکنون setup-admin.php را حذف کنید و از /admin/login وارد شوید.';
    }
}
?>
<!doctype html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>ساخت مدیر موبارو</title>
    <style>
        body{font-family:Tahoma,sans-serif;background:#f7f3f4;margin:0;padding:32px;color:#27272a}
        main{max-width:520px;margin:auto;background:#fff;padding:28px;border-radius:18px;box-shadow:0 10px 35px #0001}
        label{display:block;margin:14px 0 6px;font-weight:700}
        input{box-sizing:border-box;width:100%;padding:12px;border:1px solid #ddd;border-radius:10px}
        button{width:100%;margin-top:20px;padding:13px;border:0;border-radius:10px;background:#e11d48;color:#fff;font-weight:700;cursor:pointer}
        .message{padding:12px;border-radius:10px;background:<?= $success ? '#dcfce7' : '#fee2e2' ?>;margin-bottom:15px}
        small{display:block;color:#666;margin-top:10px;line-height:1.8}
    </style>
</head>
<body>
<main>
    <h1>ساخت اولین مدیر</h1>
    <?php if ($message !== '') : ?><div class="message"><?= e($message) ?></div><?php endif; ?>
    <?php if (!$success) : ?>
    <form method="post">
        <?= csrf() ?>
        <label>کد راه‌اندازی</label>
        <input type="password" name="setup_token" required>
        <label>نام</label>
        <input name="name" required>
        <label>نام خانوادگی</label>
        <input name="family" required>
        <label>شماره تلفن</label>
        <input name="phone" inputmode="numeric" required>
        <label>ایمیل</label>
        <input type="email" name="email">
        <label>رمز عبور قوی</label>
        <input type="password" name="password" minlength="10" required>
        <button type="submit">ساخت مدیر</button>
    </form>
    <small>کد راه‌اندازی همان مقدار SETUP_TOKEN در فایل .env است. پس از موفقیت، این فایل را با File Manager حذف کنید.</small>
    <?php endif; ?>
</main>
</body>
</html>
