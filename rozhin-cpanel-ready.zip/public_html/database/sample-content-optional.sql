-- Optional public sample content.
-- Import only after install.sql. This file contains no users, orders or private data.

SET NAMES utf8mb4;

INSERT IGNORE INTO artists (id, name, specialty, bio, avatar, instagram, working_hours, is_active) VALUES
(1, 'نازنین شریفی', 'متخصص رنگ و لایت', 'متخصص خدمات حرفه‌ای مو', 'artist-nazanin.jpg', '#', '۹ صبح تا ۸ شب', 1),
(2, 'سارا ملکی', 'آرایش و میکاپ', 'متخصص میکاپ و زیبایی', 'artist-sara.jpg', '#', '۹ صبح تا ۸ شب', 1);

INSERT IGNORE INTO services (id, title, category, price, duration, description, image, rating, is_active) VALUES
(1, 'رنگ و لایت', 'رنگ', 380000, '۱۲۰ دقیقه', 'خدمات رنگ و لایت مو', 'service-hair-color.jpg', 4.9, 1),
(2, 'آرایش عروس', 'آرایش', 1200000, '۱۸۰ دقیقه', 'میکاپ کامل و حرفه‌ای عروس', 'service-bridal.jpg', 5.0, 1),
(3, 'کوتاهی مو', 'مو', 220000, '۴۵ دقیقه', 'کوتاهی با متدهای روز', 'service-haircut.jpg', 4.8, 1),
(4, 'کراتینه مو', 'کراتینه', 800000, '۱۸۰ دقیقه', 'صافی و مراقبت مو', 'service-keratin.jpg', 4.9, 1),
(5, 'پدیکور', 'ناخن', 350000, '۶۰ دقیقه', 'مراقبت پا و ناخن', 'service-pedicure.jpg', 4.8, 1),
(6, 'مانیکور', 'ناخن', 250000, '۴۵ دقیقه', 'مراقبت و طراحی ناخن', 'service-manicure.jpg', 4.8, 1);

INSERT IGNORE INTO artist_services (artist_id, service_id) VALUES
(1, 1), (1, 3), (1, 4), (2, 2), (2, 5), (2, 6);

INSERT IGNORE INTO products
(id, name, category, price, old_price, image, description, stock, brand, is_new, is_sale, reviews, rating, is_active)
VALUES
(1, 'شامپو تقویت‌کننده', 'مو', 245000, 295000, 'product-shampoo.jpg', 'شامپو تقویت‌کننده مو', 15, 'لورآل', 0, 1, 0, 4.5, 1),
(2, 'ماسک مو کراتینه', 'مو', 315000, 395000, 'product-hair-mask.jpg', 'ماسک ترمیم‌کننده مو', 10, 'شوارتسکف', 0, 1, 0, 4.7, 1),
(3, 'رژ لب مات', 'آرایش', 89000, NULL, 'product-lipstick.jpg', 'رژ لب مات با ماندگاری بالا', 25, 'مک', 1, 0, 0, 4.3, 1),
(4, 'کرم مرطوب‌کننده', 'پوست', 175000, NULL, 'product-moisturizer.jpg', 'مرطوب‌کننده روزانه', 20, 'لاروش پوزای', 1, 0, 0, 4.6, 1),
(5, 'سشوار حرفه‌ای', 'ابزار', 1250000, 1550000, 'product-hair-dryer.jpg', 'سشوار حرفه‌ای', 5, 'فیلیپس', 0, 1, 0, 4.8, 1),
(6, 'روغن آرگان', 'مو', 350000, NULL, 'product-argan.jpg', 'روغن آرگان برای مراقبت مو', 12, '', 0, 0, 0, 4.7, 1);

INSERT IGNORE INTO product_categories (name) VALUES
('مو'), ('آرایش'), ('پوست'), ('ابزار');

INSERT IGNORE INTO product_brands (name) VALUES
('لورآل'), ('شوارتسکف'), ('مک'), ('لاروش پوزای'), ('فیلیپس');

INSERT IGNORE INTO courses
(id, title, teacher, type, image, category, description, duration, price, old_price, rating, students, level, is_free, slug, is_active)
VALUES
(1, 'تکنیک‌های حرفه‌ای رنگ مو', 'نازنین شریفی', 'online', 'course-hair-color.jpg', 'رنگ مو', 'آموزش تکنیک‌های رنگ مو', '۱۲ ساعت', 2500000, 3000000, 4.8, 0, 'متوسط', 0, 'professional-hair-coloring', 1),
(2, 'آموزش جامع میکاپ عروس', 'سارا ملکی', 'online', 'course-bridal-makeup.jpg', 'میکاپ', 'آموزش میکاپ عروس', '۸ ساعت', 1800000, 2200000, 4.9, 0, 'مبتدی', 0, 'bridal-makeup-masterclass', 1),
(3, 'مراقبت از پوست', 'مدرس آکادمی', 'online', 'course-skincare.jpg', 'پوست', 'آموزش روتین مراقبت از پوست', '۶ ساعت', 0, 0, 4.7, 0, 'مبتدی', 1, 'skincare-course', 1);

INSERT IGNORE INTO hair_models (id, title, category, image, is_active) VALUES
(1, 'مدل باب', 'مو', 'model-bob.jpg', 1),
(2, 'شینیون عروس', 'عروس', 'model-chignon.jpg', 1),
(3, 'لایت طلایی', 'رنگ', 'model-golden-light.jpg', 1),
(4, 'چتری کوتاه', 'مو', 'model-bangs.jpg', 1),
(5, 'آرایش نود', 'آرایش', 'model-nude-makeup.jpg', 1);

INSERT IGNORE INTO tutorials (id, title, category, image, duration, views, is_active) VALUES
(1, 'آموزش لایت مو', 'مو', 'tutorial-hair-light.jpg', '۴:۱۲', 0, 1),
(2, 'آرایش روزانه', 'آرایش', 'tutorial-daily-makeup.jpg', '۷:۴۵', 0, 1);

INSERT IGNORE INTO testimonials (id, name, role, text, rating, is_active) VALUES
(1, 'لیلا کریمی', 'مشتری', 'از کیفیت خدمات و رفتار مجموعه بسیار راضی بودم.', 5.0, 1),
(2, 'زهرا محمدی', 'مشتری', 'خدمات رنگ مو بسیار حرفه‌ای بود.', 4.9, 1),
(3, 'مریم حسینی', 'هنرجو', 'آموزش‌های آنلاین کاربردی و روان هستند.', 4.8, 1);
